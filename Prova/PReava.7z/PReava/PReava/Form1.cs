﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int x = 0;
            string saida = "";
            int[] MatrizA = new int[9] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int[] MatrizB = new int[9];
            for (int i = 0; i < 9; i++)
            {       
            
                if((i % 2) == 0)
                {
                    MatrizB[x] = MatrizA[i] + 7;
                    saida += "Posição:" + i + "Matriz A=" + MatrizA[i].ToString("") + "Matriz B=" + MatrizB[x].ToString("")+ "\n";
                }
                else
                {
                    MatrizB[x] = MatrizA[i] * 7;
                    saida += "Posição:" + i + "Matriz A=" + MatrizA[i].ToString("")+ "Matriz B=" + MatrizB[x].ToString("")+ "\n";
                    
                }
               ltbxMatriz.Items.Add("\n" + saida + "\n");
                x++;
                saida = "";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            ltbxMatriz.Items.Clear();
        }
    }
}