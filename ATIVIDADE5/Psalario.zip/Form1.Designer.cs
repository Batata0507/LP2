﻿namespace INSS
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.verificar = new System.Windows.Forms.Button();
            this.aliIRPF = new System.Windows.Forms.TextBox();
            this.salFami = new System.Windows.Forms.TextBox();
            this.salLiqui = new System.Windows.Forms.TextBox();
            this.descINSS = new System.Windows.Forms.TextBox();
            this.descIRPF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.salBruto = new System.Windows.Forms.MaskedTextBox();
            this.nome = new System.Windows.Forms.TextBox();
            this.numFilho = new System.Windows.Forms.NumericUpDown();
            this.aliINSS = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.numFilho)).BeginInit();
            this.SuspendLayout();
            // 
            // verificar
            // 
            this.verificar.Location = new System.Drawing.Point(136, 187);
            this.verificar.Name = "verificar";
            this.verificar.Size = new System.Drawing.Size(184, 59);
            this.verificar.TabIndex = 0;
            this.verificar.Text = "Verificar Desconto";
            this.verificar.UseVisualStyleBackColor = true;
            this.verificar.Click += new System.EventHandler(this.verificar_Click);
            // 
            // aliIRPF
            // 
            this.aliIRPF.Enabled = false;
            this.aliIRPF.Location = new System.Drawing.Point(136, 333);
            this.aliIRPF.Name = "aliIRPF";
            this.aliIRPF.Size = new System.Drawing.Size(214, 22);
            this.aliIRPF.TabIndex = 5;
            // 
            // salFami
            // 
            this.salFami.Enabled = false;
            this.salFami.Location = new System.Drawing.Point(136, 380);
            this.salFami.Name = "salFami";
            this.salFami.Size = new System.Drawing.Size(214, 22);
            this.salFami.TabIndex = 6;
            // 
            // salLiqui
            // 
            this.salLiqui.Enabled = false;
            this.salLiqui.Location = new System.Drawing.Point(136, 426);
            this.salLiqui.Name = "salLiqui";
            this.salLiqui.Size = new System.Drawing.Size(214, 22);
            this.salLiqui.TabIndex = 7;
            // 
            // descINSS
            // 
            this.descINSS.Enabled = false;
            this.descINSS.Location = new System.Drawing.Point(516, 286);
            this.descINSS.Name = "descINSS";
            this.descINSS.Size = new System.Drawing.Size(286, 22);
            this.descINSS.TabIndex = 8;
            // 
            // descIRPF
            // 
            this.descIRPF.Enabled = false;
            this.descIRPF.Location = new System.Drawing.Point(516, 343);
            this.descIRPF.Name = "descIRPF";
            this.descIRPF.Size = new System.Drawing.Size(286, 22);
            this.descIRPF.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "Numero de filhos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Aliquota INSS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 339);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "Aliquota IPRF";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 386);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Salario familia";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 432);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 18;
            this.label7.Text = "Salario liquido";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(411, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "Desconto INSS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(411, 349);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Desconto IRPF";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 16);
            this.label1.TabIndex = 21;
            this.label1.Text = "Nome do funcionario";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "Salario Bruto";
            // 
            // salBruto
            // 
            this.salBruto.Location = new System.Drawing.Point(172, 71);
            this.salBruto.Mask = "990000.00";
            this.salBruto.Name = "salBruto";
            this.salBruto.Size = new System.Drawing.Size(338, 22);
            this.salBruto.TabIndex = 23;
            this.salBruto.Validated += new System.EventHandler(this.salBruto_Validated);
            // 
            // nome
            // 
            this.nome.Location = new System.Drawing.Point(172, 26);
            this.nome.Name = "nome";
            this.nome.Size = new System.Drawing.Size(337, 22);
            this.nome.TabIndex = 24;
            this.nome.TextChanged += new System.EventHandler(this.nome_TextChanged);
            this.nome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.nome_KeyPress);
            this.nome.Validated += new System.EventHandler(this.nome_Validated);
            // 
            // numFilho
            // 
            this.numFilho.Location = new System.Drawing.Point(172, 123);
            this.numFilho.Name = "numFilho";
            this.numFilho.Size = new System.Drawing.Size(120, 22);
            this.numFilho.TabIndex = 25;
            // 
            // aliINSS
            // 
            this.aliINSS.Enabled = false;
            this.aliINSS.Location = new System.Drawing.Point(138, 283);
            this.aliINSS.Name = "aliINSS";
            this.aliINSS.Size = new System.Drawing.Size(212, 22);
            this.aliINSS.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 460);
            this.Controls.Add(this.aliINSS);
            this.Controls.Add(this.numFilho);
            this.Controls.Add(this.nome);
            this.Controls.Add(this.salBruto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.descIRPF);
            this.Controls.Add(this.descINSS);
            this.Controls.Add(this.salLiqui);
            this.Controls.Add(this.salFami);
            this.Controls.Add(this.aliIRPF);
            this.Controls.Add(this.verificar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numFilho)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button verificar;
        private System.Windows.Forms.TextBox aliIRPF;
        private System.Windows.Forms.TextBox salFami;
        private System.Windows.Forms.TextBox salLiqui;
        private System.Windows.Forms.TextBox descINSS;
        private System.Windows.Forms.TextBox descIRPF;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox salBruto;
        private System.Windows.Forms.TextBox nome;
        private System.Windows.Forms.NumericUpDown numFilho;
        private System.Windows.Forms.TextBox aliINSS;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

