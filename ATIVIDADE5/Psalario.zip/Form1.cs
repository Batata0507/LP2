﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSS
{
    public partial class Form1 : Form
    {
        double SalBru;
        public Form1()
        {
            InitializeComponent();

        }
        private void nome_Validated(object sender, EventArgs e)
        {
            if (nome.Text == "")
            {
                MessageBox.Show("digite um nome");
                nome.Focus();
            }
        }
        private void nome_KeyPress(object sender, KeyPressEventArgs e)
        {
            {  
                if (Char.IsNumber(e.KeyChar) ||
                Char.IsPunctuation(e.KeyChar))
                {
                    SendKeys.Send("{BACKSPACE}");
                }
            }
        }
        private void salBruto_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(salBruto.Text, out SalBru))
            {
                MessageBox.Show("Digite um Valor Correto");
                salBruto.Focus();
            }
        }
        private void verificar_Click(object sender, EventArgs e)
        {

            double DescINSS = 0, DescIRPF = 0, SalaFamilia = 0, SalLiquido = 0;
                                                                        // Aliquoa INSS e Desconto INSS
            if (SalBru <= 800.47)
            {
                aliINSS.Text = "7,65%";
                DescINSS = 0.0765 * SalBru;

            }
            else if (SalBru <= 1050)
            {
                aliINSS.Text = "8.65%%";
                DescINSS = 0.0865 * SalBru;
            }
            else if (SalBru >= 1050.1 && SalBru <= 1400.77)
            {
                aliINSS.Text = "9,00%";
                DescINSS = 0.09 * SalBru;
            }
            else if (SalBru >= 1400.78 && SalBru <= 2801.56)
            {
                aliINSS.Text = "11,00%";
                DescINSS = 0.11 * SalBru;
            }
            else if (SalBru >= 2801.57)
            {
                aliINSS.Text = "Teto";
                DescINSS = 308.17;
            }
            descINSS.Text = DescINSS.ToString("N2");
                                                        //Aliquoa IRFP e Desconto IRPF
            if (SalBru <= 1257.12)
            {
                aliIRPF.Text = "ISENTO";
                DescIRPF = 0;
            }
            else if (SalBru <= 2512.08)
            {
                aliIRPF.Text = "15,00%%";
                DescIRPF = 0.15 * SalBru;
            }
            else if (SalBru >= 2512.09)
            {
                aliIRPF.Text = "27,50%";
                DescIRPF = 0.275 * SalBru;
            }
            descIRPF.Text = DescIRPF.ToString("N2");
            if (SalBru < 435.32)
            {
                var y = Convert.ToInt16(numFilho.Value);
                SalaFamilia = y * 22.33;
                salFami.Text = SalaFamilia.ToString();
            }
            else if (SalBru <= 654.61)
            {
                var y = Convert.ToInt16(numFilho.Value);
                SalaFamilia = y * 15.74;
                salFami.Text = SalaFamilia.ToString();
            }
            else if (SalBru >= 654.62)
            {
                var y = Convert.ToInt16(numFilho.Value);
                SalaFamilia = y * 15.74;
                salFami.Text = SalaFamilia.ToString();
            }
            SalLiquido = ((SalBru - DescINSS) - DescIRPF) + SalaFamilia;
            salLiqui.Text = SalLiquido.ToString();
        }


        private void nome_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
